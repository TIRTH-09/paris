import React, { useState } from 'react';
import { BannerHeader } from './components/BannerHeader';
import { BannerHeroContent } from './components/BannerHeroContent';
import { BannerGlassCards } from './components/BannerGlassCards';
import { ParisStorySection } from './components/ParisStorySection';
import { ParisMomentsSection } from './components/ParisMomentsSection';
import { ParisFinalCtaSection } from './components/ParisFinalCtaSection';
import { InteractiveModals } from './components/InteractiveModals';
import { BackgroundMode, BannerData, LanguageOption, ActiveModal } from './types';

// AI Generated hero backdrop image
import heroImage from './assets/images/clean_energy_hero_1786182860009.jpg';

const DEFAULT_BANNER_DATA: BannerData = {
  companyName: 'PARIS',
  headline: 'Experience Paris like never before',
  subtitle: 'From moonlit walks along the Seine to hidden cafés in Montmartre, experience Paris through journeys designed around you.',
  ctaText: 'Explore Paris · Plan Your Journey',
  card1Category: 'Explore',
  card1Title: 'Iconic Paris',
  card1Text: 'Discover world-renowned landmarks, timeless architecture, and golden sunsets along the Seine.',
  card2Category: 'Experience',
  card2Title: 'Hidden Paris',
  card2Text: 'Step beyond the landmarks and uncover charming streets, local cafés, and unforgettable moments.',
  generatedEnergyValue: '12 Districts',
  generatedEnergyText: 'uncovering famous art, world heritage, and timeless monuments',
  impactValue: '100% Bespoke',
  impactText: 'journeys crafted specifically around your travel desires and rhythm.',
};

export default function App() {
  const [bgMode, setBgMode] = useState<BackgroundMode>('studio-dark');
  const [bannerData, setBannerData] = useState<BannerData>(DEFAULT_BANNER_DATA);
  const [activeNav, setActiveNav] = useState('Overview');
  const [activeModal, setActiveModal] = useState<ActiveModal>(null);
  const [selectedLang, setSelectedLang] = useState<LanguageOption>({
    code: 'EN',
    name: 'English (UK)',
    flag: '🇬🇧',
  });

  const resetDefault = () => {
    setBannerData(DEFAULT_BANNER_DATA);
    setBgMode('studio-dark');
    setActiveNav('Home');
  };

  // Compute container background styles based on selected mode
  const getBackgroundStyles = () => {
    switch (bgMode) {
      case 'studio-dark':
        return {
          className: 'bg-black text-white',
          overlay: null,
        };

      case 'studio-teal':
        return {
          className: 'bg-gradient-to-br from-[#126563] via-[#1b7a77] to-[#0e4b48] text-white',
          overlay: (
            <>
              {/* Subtle radial highlights for studio lighting */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(255,255,255,0.15),transparent_65%)] pointer-events-none" />
              <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-400/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />
            </>
          ),
        };

      case 'studio-light':
        return {
          className: 'bg-slate-100 text-slate-900',
          overlay: (
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(255,255,255,0.9),rgba(226,232,240,0.95))]" />
          ),
        };

      case 'photo':
        return {
          className: 'bg-slate-900 text-white',
          overlay: (
            <>
              {/* Photo background with soft color filter matching reference */}
              <div
                className="absolute inset-0 bg-cover bg-center transition-all duration-700"
                style={{ backgroundImage: `url(${heroImage})` }}
              />
              <div className="absolute inset-0 bg-teal-900/30 backdrop-hue-rotate-15 mix-blend-multiply" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/30" />
            </>
          ),
        };

      case 'transparent-grid':
        return {
          className: 'bg-slate-900 text-white',
          overlay: (
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.4) 1px, transparent 1px)`,
                backgroundSize: '24px 24px',
              }}
            />
          ),
        };

      default:
        return { className: 'bg-teal-800', overlay: null };
    }
  };

  const currentBg = getBackgroundStyles();

  return (
    <div className={`relative min-h-screen w-full flex flex-col justify-between overflow-hidden select-none transition-colors duration-500 ${currentBg.className}`}>
      {/* Background Layer */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        {currentBg.overlay}
      </div>

      {/* Sophisticated Dark Corner Architectural Crosshairs */}
      <div className="corner-frame-tl z-20 hidden md:block" />
      <div className="corner-frame-br z-20 hidden md:block" />

      {/* Main Banner Composition (Top Nav -> Hero Content -> Bottom Glass Cards) */}
      <div id="section-overview" className="relative z-10 min-h-screen flex flex-col justify-between">
        {/* 1. Header Navigation */}
        <BannerHeader
          companyName={bannerData.companyName}
          activeNav={activeNav}
          setActiveNav={setActiveNav}
          openModal={(modal) => setActiveModal(modal)}
          selectedLang={selectedLang}
          setSelectedLang={setSelectedLang}
          isTransparentGrid={bgMode === 'transparent-grid'}
        />

        {/* 2. Main Hero Content */}
        <BannerHeroContent
          headline={bannerData.headline}
          subtitle={bannerData.subtitle}
          ctaText={bannerData.ctaText}
          onCtaClick={() => setActiveModal('consultation')}
          openModal={(modal) => setActiveModal(modal)}
        />

        {/* 3. Bottom Glassmorphic Cards */}
        <BannerGlassCards
          card1Category={bannerData.card1Category}
          card1Title={bannerData.card1Title}
          card1Text={bannerData.card1Text}
          card2Category={bannerData.card2Category}
          card2Title={bannerData.card2Title}
          card2Text={bannerData.card2Text}
          openModal={(modal) => setActiveModal(modal)}
        />
      </div>

      {/* Section 2: Where Every Street Tells a Story */}
      <ParisStorySection openModal={(modal) => setActiveModal(modal)} />

      {/* Section 3: Experiences — Your Paris Moments */}
      <ParisMomentsSection openModal={(modal) => setActiveModal(modal)} />

      {/* Section 4: Final CTA — Your Story Starts Here */}
      <ParisFinalCtaSection openModal={(modal) => setActiveModal(modal)} />

      {/* Interactive Modals and Drawers */}
      <InteractiveModals
        activeModal={activeModal}
        closeModal={() => setActiveModal(null)}
        bannerData={bannerData}
      />
    </div>
  );
}
